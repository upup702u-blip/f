const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, ActivityType, ButtonBuilder, ButtonStyle, EmbedBuilder, StringSelectMenuBuilder, ActionRowBuilder } = require('discord.js');
const cfg = require('./config.json');
const GameState = require('./structures/GameState');
const createButtonRows = require('./utils/createButtonRows');

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers] });
const game = new GameState();

function isOwner(id){ return Array.isArray(cfg.owners) && cfg.owners.includes(id); }

client.once('ready', ()=> {
  console.log('Bot ready', client.user.tag);
  client.user.setActivity('Mafia Game', { type: ActivityType.Playing });
});

// Centralized message handler (merges helper commands + game start commands)
client.on('messageCreate', async message => {
  if (message.author.bot) return;
  const content = message.content.trim();

  // prefix-based helper commands (prefix is '.' in helper originally)
  if (content.startsWith('.')) {
    const [cmd, ...args] = content.slice(1).split(/ +/);
    // .owner add/remove/list integrated
    if (cmd === 'owner') {
      if (!isOwner(message.author.id)) return message.react('❌');
      const sub = args[0];
      if (!sub) return message.react('❓');
      if (sub === 'add' && args[1]) {
        const id = args[1].replace(/[^0-9]/g,'');
        if (!cfg.owners.includes(id)) { cfg.owners.push(id); fs.writeFileSync('./config.json', JSON.stringify(cfg,null,2)); return message.react('✅'); }
        return message.react('⚠️');
      } else if (sub === 'remove' && args[1]) {
        const id = args[1].replace(/[^0-9]/g,'');
        cfg.owners = cfg.owners.filter(x=>x!==id); fs.writeFileSync('./config.json', JSON.stringify(cfg,null,2)); return message.react('✅');
      } else if (sub === 'list') {
        return message.channel.send(`Owners:\n${cfg.owners.map(id=>`<@${id}>`).join('\n')}`);
      }
    }

    // .set <key> used for images: .set wolves_win (then bot asks for attachment)
    if (cmd === 'set') {
      if (!isOwner(message.author.id)) return message.react('❌');
      const key = args[0];
      if (!key || !cfg.images[key]) return message.reply('Unknown image key. Available: ' + Object.keys(cfg.images).join(', '));
      await message.reply('📤 أرسل الآن الصورة كمرفق في رسالة هذه القناة (30s)');
      const filter = m => m.author.id === message.author.id && m.attachments.size>0;
      try {
        const collected = await message.channel.awaitMessages({ filter, max:1, time:30000, errors:['time'] });
        const attachment = collected.first().attachments.first();
        const fetch = require('node-fetch');
        const res = await fetch(attachment.url);
        const buffer = await res.buffer();
        const dest = path.join(__dirname, 'assets','images', cfg.images[key]);
        fs.writeFileSync(dest, buffer);
        return message.reply('✅ تم تحديث الصورة.');
      } catch (e) {
        return message.reply('❌ لم يتم استقبال صورة.');
      }
    }
  }

  // owner-only commands
  if (content === '-تحكم') {
    if (!isOwner(message.author.id)) return message.reply('❌ هذه اللوحة خاصة بالمالكين.');
    // send embed dashboard with buttons (admin actions)
    const embed = new EmbedBuilder().setTitle('لوحة تحكم الماستر').setColor(0x1F8BFF).setDescription('الأزرار خاصة بالمالكين فقط');
    const buttons = [
      new ButtonBuilder().setCustomId('admin_pause').setLabel('⏸️ إيقاف مؤقت').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('admin_resume').setLabel('▶️ استئناف').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('admin_end').setLabel('❌ إنهاء اللعبة').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId('admin_reveal').setLabel('🕵️ كشف الأدوار').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('admin_redistribute').setLabel('🔄 إعادة توزيع').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('admin_declare_town').setLabel('🏆 أعلن فوز القرويين').setStyle(ButtonStyle.Success)
    ];
    await message.channel.send({ embeds: [embed], components: createButtonRows(buttons,3) });
    return;
  }

  // -setrole alias: allow owner to set controller role by mention
  if (content.startsWith('-setrole')) {
    if (!isOwner(message.author.id)) return message.reply('❌ فقط المالك يستطيع هذا.');
    const role = message.mentions.roles.first();
    if (!role) return message.reply('📛 اذكر الرول: -setrole @role');
    cfg.controllerRoleId = role.id; fs.writeFileSync('./config.json', JSON.stringify(cfg,null,2));
    return message.reply(`✅ تم تسجيل رول التحكم: ${role.name}`);
  }

  // Start game command: owner OR holder of controllerRoleId
  if (content === '-الذيب') {
    const member = message.member;
    const ok = isOwner(message.author.id) || (cfg.controllerRoleId && member.roles.cache.has(cfg.controllerRoleId));
    if (!ok) return message.reply('❌ ليس لديك صلاحية بدء اللعبة.');
    if (game.gameActive) return message.reply('⚠️ هناك لعبة جارية.');
    game.reset(); game.gameActive = true;
    await message.channel.send('✅ تم بدء اللوبي — اضغط دخول للانضمام');
    const join = new ButtonBuilder().setCustomId('join_game').setLabel('دخول').setStyle(ButtonStyle.Primary);
    const leave = new ButtonBuilder().setCustomId('leave_game').setLabel('انسحاب').setStyle(ButtonStyle.Secondary);
    await message.channel.send({ content: `لوبي مفتوح — ${game.players.length}/${cfg.maxPlayers}`, components: createButtonRows([join, leave]) });
    setTimeout(()=> { if (game.players.length < cfg.minPlayers) { message.channel.send('لم يجتمع العدد الكافي.'); game.reset(); } else { message.channel.send('🚨 توزيع الادوار ... (تجريبي)'); } }, cfg.startTime);
    return;
  }

  // other minor helper commands
  if (content === '.more' && isOwner(message.author.id)) {
    // show settings select menu (simplified)
    const menu = new StringSelectMenuBuilder().setCustomId('settings_select').setPlaceholder('اختر إعداد').addOptions([
      { label: 'وقت البدء', value: 'change_start_time' },
      { label: 'وقت الذئاب', value: 'change_mafia_time' },
      { label: 'الحد الأقصى للاعبين', value: 'change_max_players' }
    ]);
    await message.channel.send({ content: 'لوحة الإعدادات', components: [new ActionRowBuilder().addComponents(menu)] });
    return;
  }

  // points command
  if (content === '-نقاطي') {
    const sqlite3 = require('sqlite3').verbose();
    const db = new sqlite3.Database('./points.db');
    db.get("SELECT score FROM points WHERE id=?", [message.author.id], (err, row) => {
      if (!row) return message.reply("📦 ليس لديك نقاط بعد!");
      message.reply(`🏆 نقاطك: **${row.score}**`);
    });
    return;
  }
});

// interaction handler for buttons & select menus
client.on('interactionCreate', async interaction => {
  try {
    if (interaction.isButton()) {
      const id = interaction.customId;
      // admin buttons guard
      const cfg = require('./config.json');
      if (id.startsWith('admin_')) {
        if (!isOwner(interaction.user.id)) return interaction.reply({ content: '❌ للأونرز فقط.', ephemeral: true });
        // pass to admin handler (simple implementations)
        if (id === 'admin_pause') { game.clearAllTimeouts(); return interaction.reply({ content: '⏸️ توقفت المؤقتات.', ephemeral: true }); }
        if (id === 'admin_resume') { return interaction.reply({ content: '▶️ استئناف غير متاح الآن.', ephemeral: true }); }
        if (id === 'admin_end') { game.clearAllTimeouts(); game.reset(); return interaction.reply({ content: '❌ انتهت اللعبة.', ephemeral: true }); }
        if (id === 'admin_reveal') {
          let txt = '🔎 أدوار اللاعبين:\n'; for (const p of game.allPlayers) txt += `• <@${p}> — ${game.playerRoles.get(p)||'قروي'}\n`;
          return interaction.reply({ content: txt, ephemeral: true });
        }
        if (id === 'admin_redistribute') { return interaction.reply({ content: '🔄 تم (محاكاة) إعادة التوزيع.', ephemeral: true }); }
        if (id === 'admin_declare_town') { game.clearAllTimeouts(); game.reset(); return interaction.reply({ content: '🏆 أعلن فوز القرويين (يدوياً).', ephemeral: true }); }
      }

      // join/leave buttons
      if (id === 'join_game') {
        if (game.players.includes(interaction.user.id)) return interaction.reply({ content: '✅ أنت بالفعل في اللعبة.', ephemeral: true });
        game.players.push(interaction.user.id); if (!game.allPlayers.includes(interaction.user.id)) game.allPlayers.push(interaction.user.id);
        return interaction.reply({ content: '✅ انضممت للعبة.', ephemeral: true });
      }
      if (id === 'leave_game') {
        if (!game.players.includes(interaction.user.id)) return interaction.reply({ content: '❌ لست في اللعبة.', ephemeral: true });
        game.players = game.players.filter(p => p !== interaction.user.id);
        return interaction.reply({ content: '❌ غادرت اللعبة.', ephemeral: true });
      }
    } // end button

    if (interaction.isStringSelectMenu()) {
      const id = interaction.customId;
      if (id === 'settings_select') {
        const selected = interaction.values[0];
        // simplified settings change flow for demo
        return interaction.reply({ content: `تم اختيار: ${selected}. الرجاء كتابة القيمة الجديدة في الشات.` , ephemeral: true });
      }
    }
  } catch (e) {
    console.error('Interaction handler error', e);
  }
});

client.login(cfg.token);
