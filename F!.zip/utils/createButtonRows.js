const { ActionRowBuilder } = require('discord.js');
function createButtonRows(buttons, perRow = 5) {
  const rows = [];
  for (let i = 0; i < buttons.length; i += perRow) {
    const row = new ActionRowBuilder();
    row.addComponents(...buttons.slice(i, i + perRow));
    rows.push(row);
  }
  return rows;
}
module.exports = createButtonRows;
