const {
  EmbedBuilder,
  PermissionFlagsBits,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require("discord.js");
const GameState = require("./GameState");
const { generateBoard, buildBoardComponents, buildBoardEmbed } = require("./board");
const { addScore } = require("./leaderboard");
const { config } = require("../config");

const games = new Map();

function getGame(channelId) {
  return games.get(channelId) || null;
}

function createGame(channel) {
  const game = new GameState(channel, config);
  games.set(channel.id, game);
  return game;
}

function deleteGame(channelId) {
  const game = games.get(channelId);
  if (game) game.clearAllTimeouts();
  games.delete(channelId);
}

async function refreshBoard(game) {
  if (!game || !game.channel) return;

  const payload = {
    embeds: [buildBoardEmbed(game)],
    components: buildBoardComponents(game),
  };

  const msg = await game.channel.send(payload);
  game.boardMessage = msg;
}

// ---------- LOBBY ----------

function buildLobbyEmbed(game, remainingSec) {
  const bluePlayers = game.blueTeam.size;
  const redPlayers = game.redTeam.size;
  const blueLeader = game.blueLeader ? 1 : 0;
  const redLeader = game.redLeader ? 1 : 0;
  const maxPlayers = game.config.maxPlayersPerTeam || 6;

  return new EmbedBuilder()
    .setTitle("🎮 كودنيمز - اللوبي")
    .setDescription(
      "اضغط على الأزرار في الأسفل لاختيار فريقك.\n" +
        "لا يشترط اكتمال العدد، المهم أن يحتوي كل فريق على **قائد واحد** و **لاعب واحد على الأقل**.\n\n" +
        `⏱ سيتم بدء اللعبة تلقائيًا بعد **${remainingSec}** ثانية.`
    )
    .addFields(
      {
        name: "🔵 فريق الأزرق",
        value:
          `القادة: ${blueLeader}/1\n` +
          `اللاعبون: ${bluePlayers}/${maxPlayers}`,
        inline: true,
      },
      {
        name: "🔴 فريق الأحمر",
        value:
          `القادة: ${redLeader}/1\n` +
          `اللاعبون: ${redPlayers}/${maxPlayers}`,
        inline: true,
      }
    )
    .setColor(0x3498db);
}

function buildLobbyComponents() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("join_blue_leader")
        .setLabel("قائد الأزرق")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("join_blue_player")
        .setLabel("فريق الأزرق")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("join_red_leader")
        .setLabel("قائد الأحمر")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId("join_red_player")
        .setLabel("فريق الأحمر")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId("leave_game")
        .setLabel("خروج من اللعبة")
        .setStyle(ButtonStyle.Secondary)
    ),
  ];
}

async function startLobby(message) {
  const channel = message.channel;

  const existing = getGame(channel.id);
  if (existing && existing.stage !== "ENDED") {
    return message.reply("هناك لعبة قيد التشغيل بالفعل في هذه القناة.");
  }

  const game = createGame(channel);

  const embed = buildLobbyEmbed(game, config.lobbyTimeSec);
  const msg = await channel.send({
    embeds: [embed],
    components: buildLobbyComponents(),
  });

  game.lobbyMessage = msg;

  let remaining = config.lobbyTimeSec;

  game.lobbyInterval = setInterval(async () => {
    if (!game.lobbyMessage || game.stage !== "LOBBY") return;
    remaining -= 5;
    if (remaining < 0) remaining = 0;
    try {
      await game.lobbyMessage.edit({
        embeds: [buildLobbyEmbed(game, remaining)],
        components: buildLobbyComponents(),
      });
    } catch (e) {}
  }, 5000);

  game.lobbyTimeout = setTimeout(() => {
    startGameIfReady(game);
  }, config.lobbyTimeSec * 1000);
}

function buildJoinResponseEmbed(success, text) {
  return new EmbedBuilder()
    .setDescription((success ? "✅ " : "❌ ") + text)
    .setColor(success ? 0x2ecc71 : 0xe74c3c);
}

async function handleLobbyButton(interaction) {
  const game = getGame(interaction.channel.id);
  if (!game || game.stage !== "LOBBY") {
    const embed = buildJoinResponseEmbed(false, "لا يوجد لوبي نشط حالياً في هذه القناة.");
    return interaction.reply({ embeds: [embed], ephemeral: true });
  }

  const userId = interaction.user.id;
  const id = interaction.customId;

  const reply = (ok, msg) => {
    const embed = buildJoinResponseEmbed(ok, msg);
    return interaction.reply({ embeds: [embed], ephemeral: true });
  };

  if (id === "leave_game") {
    const wasLeader = game.blueLeader === userId || game.redLeader === userId;
    const wasPlayer = game.blueTeam.has(userId) || game.redTeam.has(userId);

    game.blueTeam.delete(userId);
    game.redTeam.delete(userId);
    if (game.blueLeader === userId) game.blueLeader = null;
    if (game.redLeader === userId) game.redLeader = null;

    const msg = wasLeader || wasPlayer
      ? "تمت إزالتك من اللعبة بنجاح."
      : "أنت غير مشارك في اللعبة حالياً.";
    return reply(true, msg);
  }

  const maxPlayers = game.config.maxPlayersPerTeam || 6;

  if (id === "join_blue_leader") {
    if (game.redLeader === userId) {
      return reply(false, "أنت بالفعل قائد فريق الأحمر، لا يمكنك قيادة فريقين في نفس الوقت.");
    }
    if (game.blueLeader === userId) {
      return reply(false, "أنت بالفعل قائد فريق الأزرق.");
    }
    if (game.blueTeam.has(userId) || game.redTeam.has(userId)) {
      return reply(false, "لا يمكنك أن تكون قائدًا ولاعبًا في نفس الوقت. اخرج من الفريق أولاً.");
    }

    if (game.blueLeader && game.blueLeader !== userId) {
      return reply(false, "يوجد بالفعل قائد لفريق الأزرق.");
    }

    game.blueLeader = userId;
    game.redTeam.delete(userId);
    if (game.redLeader === userId) game.redLeader = null;

    return reply(true, "لقد أصبحت **قائد فريق الأزرق 🔵**.");
  }

  if (id === "join_red_leader") {
    if (game.blueLeader === userId) {
      return reply(false, "أنت بالفعل قائد فريق الأزرق، لا يمكنك قيادة فريقين في نفس الوقت.");
    }
    if (game.redLeader === userId) {
      return reply(false, "أنت بالفعل قائد فريق الأحمر.");
    }
    if (game.blueTeam.has(userId) || game.redTeam.has(userId)) {
      return reply(false, "لا يمكنك أن تكون قائدًا ولاعبًا في نفس الوقت. اخرج من الفريق أولاً.");
    }

    if (game.redLeader && game.redLeader !== userId) {
      return reply(false, "يوجد بالفعل قائد لفريق الأحمر.");
    }

    game.redLeader = userId;
    game.blueTeam.delete(userId);
    if (game.blueLeader === userId) game.blueLeader = null;

    return reply(true, "لقد أصبحت **قائد فريق الأحمر 🔴**.");
  }

  if (id === "join_blue_player") {
    if (game.blueLeader === userId || game.redLeader === userId) {
      return reply(false, "لا يمكنك الانضمام كلاعب وأنت قائد. اخرج من القيادة أولاً.");
    }

    if (game.blueTeam.size >= maxPlayers) {
      return reply(false, `فريق الأزرق ممتلئ حاليًا. الحد الأقصى هو ${maxPlayers}.`);
    }

    game.blueTeam.add(userId);
    game.redTeam.delete(userId);

    return reply(true, "لقد انضممت إلى **فريق الأزرق 🔵**.");
  }

  if (id === "join_red_player") {
    if (game.blueLeader === userId || game.redLeader === userId) {
      return reply(false, "لا يمكنك الانضمام كلاعب وأنت قائد. اخرج من القيادة أولاً.");
    }

    if (game.redTeam.size >= maxPlayers) {
      return reply(false, `فريق الأحمر ممتلئ حاليًا. الحد الأقصى هو ${maxPlayers}.`);
    }

    game.redTeam.add(userId);
    game.blueTeam.delete(userId);

    return reply(true, "لقد انضممت إلى **فريق الأحمر 🔴**.");
  }
}

async function startGameIfReady(game) {
  if (game.stage !== "LOBBY") return;

  game.clearAllTimeouts();

  if (
    !game.blueLeader ||
    !game.redLeader ||
    game.blueTeam.size === 0 ||
    game.redTeam.size === 0
  ) {
    game.end();
    deleteGame(game.channel.id);
    await game.channel.send(
      "لا يمكن بدء اللعبة. يجب أن يحتوي كل فريق على **قائد واحد على الأقل** و **لاعب واحد على الأقل**."
    );
    return;
  }

  game.stage = "IN_PROGRESS";

  await lockChannelForGame(game);

  game.boardWords = generateBoard();
  const deadly = game.boardWords.find((w) => w.type === "DEADLY");
  game.deadlyWordId = deadly ? deadly.id : null;
  game.neutralIds = new Set(
    game.boardWords.filter((w) => w.type === "NEUTRAL").map((w) => w.id)
  );

  game.currentTurn = Math.random() < 0.5 ? "BLUE" : "RED";

  await refreshBoard(game);
  await startNewTurn(game);
}

async function lockChannelForGame(game) {
  const channel = game.channel;
  const guild = channel.guild;
  const everyone = guild.roles.everyone;

  await channel.permissionOverwrites.edit(everyone, {
    SendMessages: false,
  }).catch(() => {});

  if (game.blueLeader) {
    await channel.permissionOverwrites.edit(game.blueLeader, {
      SendMessages: true,
    }).catch(() => {});
  }
  if (game.redLeader) {
    await channel.permissionOverwrites.edit(game.redLeader, {
      SendMessages: true,
    }).catch(() => {});
  }
}

async function restoreChannelPermissions(game) {
  const channel = game.channel;
  const guild = channel.guild;
  const everyone = guild.roles.everyone;

  await channel.permissionOverwrites.edit(everyone, {
    SendMessages: true,
  }).catch(() => {});

  if (game.blueLeader) {
    await channel.permissionOverwrites.delete(game.blueLeader).catch(() => {});
  }
  if (game.redLeader) {
    await channel.permissionOverwrites.delete(game.redLeader).catch(() => {});
  }
}

// ---------- Hint & Turns ----------

function getTeamWordsText(game, team) {
  const words = game.boardWords.filter((w) => w.type === team);
  if (!words.length) return "لا توجد كلمات لفريقك حتى الآن.";
  return words
    .map((w) => `${w.label}${w.chosenBy ? " ✅" : ""}`)
    .join("، ");
}

async function sendLeaderEphemeral(interaction, game, team) {
  const userId = interaction.user.id;
  if (team === "BLUE" && game.blueLeader !== userId) {
    return interaction.reply({
      content: "هذا الزر مخصص لقائد فريق الأزرق فقط.",
      ephemeral: true,
    });
  }
  if (team === "RED" && game.redLeader !== userId) {
    return interaction.reply({
      content: "هذا الزر مخصص لقائد فريق الأحمر فقط.",
      ephemeral: true,
    });
  }

  const text = getTeamWordsText(game, team);
  const seconds = game.config.hintTimeSec || 80;

  const hintRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`open_hint_${team}`)
      .setLabel("🧠 تلميح")
      .setStyle(ButtonStyle.Primary)
  );

  return interaction.reply({
    content:
      `هذه كلمات فريقك ${
        team === "BLUE" ? "🔵 (الأزرق)" : "🔴 (الأحمر)"
      }:\n${text}\n\n` +
      `⏱ لديك حوالي **${seconds} ثانية** من بداية دور فريقك لإرسال التلميح قبل أن يُلغى الدور.\n\n` +
      "لإرسال التلميح:\n" +
      "1. اضغط زر **🧠 تلميح** في الأسفل.\n" +
      "2. في النافذة اكتب التلميح (كلمة واحدة) وعدد الكلمات (1 - 5).",
    components: [hintRow],
    ephemeral: true,
  });
}

async function handleViewTeamWords(interaction, team) {
  const game = getGame(interaction.channel.id);
  if (!game || game.stage !== "IN_PROGRESS") {
    return interaction.reply({
      content: "لا توجد لعبة نشطة حالياً في هذه القناة.",
      ephemeral: true,
    });
  }
  return sendLeaderEphemeral(interaction, game, team);
}

async function openHintModal(interaction, team) {
  const game = getGame(interaction.channel.id);
  if (!game || game.stage !== "IN_PROGRESS") {
    return interaction.reply({
      content: "لا توجد لعبة نشطة حالياً في هذه القناة.",
      ephemeral: true,
    });
  }

  const userId = interaction.user.id;
  if (team === "BLUE" && game.blueLeader !== userId) {
    return interaction.reply({
      content: "هذا الزر مخصص لقائد فريق الأزرق فقط.",
      ephemeral: true,
    });
  }
  if (team === "RED" && game.redLeader !== userId) {
    return interaction.reply({
      content: "هذا الزر مخصص لقائد فريق الأحمر فقط.",
      ephemeral: true,
    });
  }

  if (!game.hintState || game.hintState.phase !== "AWAIT_HINT") {
    return interaction.reply({
      content: "لا يمكنك إرسال التلميح الآن، انتظر دور فريقك.",
      ephemeral: true,
    });
  }

  if (game.hintState.team !== team) {
    return interaction.reply({
      content: "ليس هذا دور فريقك حالياً.",
      ephemeral: true,
    });
  }

  const modal = new ModalBuilder()
    .setCustomId(`hint_modal_${team}`)
    .setTitle("إرسال التلميح");

  const hintInput = new TextInputBuilder()
    .setCustomId("hint_word")
    .setLabel("اكتب التلميح (كلمة واحدة فقط)")
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const countInput = new TextInputBuilder()
    .setCustomId("hint_count")
    .setLabel("عدد الكلمات المسموح بها (من 1 إلى 5)")
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const row1 = new ActionRowBuilder().addComponents(hintInput);
  const row2 = new ActionRowBuilder().addComponents(countInput);

  modal.addComponents(row1, row2);

  return interaction.showModal(modal);
}

async function handleHintModalSubmit(interaction) {
  const game = getGame(interaction.channel.id);
  if (!game || game.stage !== "IN_PROGRESS") {
    return interaction.reply({
      content: "لا توجد لعبة نشطة حالياً في هذه القناة.",
      ephemeral: true,
    });
  }

  const customId = interaction.customId;
  const parts = customId.split("_");
  const team = parts[2];

  if (!["BLUE", "RED"].includes(team)) {
    return interaction.reply({
      content: "حدث خطأ في التعرف على الفريق.",
      ephemeral: true,
    });
  }

  const userId = interaction.user.id;
  if (team === "BLUE" && game.blueLeader !== userId) {
    return interaction.reply({
      content: "هذا النموذج مخصص لقائد فريق الأزرق فقط.",
      ephemeral: true,
    });
  }
  if (team === "RED" && game.redLeader !== userId) {
    return interaction.reply({
      content: "هذا النموذج مخصص لقائد فريق الأحمر فقط.",
      ephemeral: true,
    });
  }

  if (!game.hintState || game.hintState.phase !== "AWAIT_HINT") {
    return interaction.reply({
      content: "لا يمكنك إرسال التلميح في هذه اللحظة.",
      ephemeral: true,
    });
  }

  if (game.hintState.team !== team) {
    return interaction.reply({
      content: "ليس هذا دور فريقك حالياً.",
      ephemeral: true,
    });
  }

  const word = interaction.fields.getTextInputValue("hint_word").trim();
  const countStr = interaction.fields.getTextInputValue("hint_count").trim();

  if (!word) {
    return interaction.reply({
      content: "التلميح لا يمكن أن يكون فارغًا.",
      ephemeral: true,
    });
  }

  if (word.split(/\s+/).length > 1) {
    return interaction.reply({
      content: "التلميح يجب أن يكون **كلمة واحدة فقط**.",
      ephemeral: true,
    });
  }

  const count = parseInt(countStr, 10);
  if (isNaN(count) || count < 1 || count > 5) {
    return interaction.reply({
      content: "عدد الكلمات يجب أن يكون رقمًا من 1 إلى 5.",
      ephemeral: true,
    });
  }

  game.hintState.hintWord = word;
  game.hintState.guessCount = count;

  await finalizeHint(game);

  return interaction.reply({
    content:
      `تم تسجيل تلميحك: **${word}**\n` +
      `عدد الكلمات المسموح بها في هذه الجولة: **${count}**.`,
    ephemeral: true,
  });
}

async function startNewTurn(game, reasonMsg) {
  if (game.hintTimeout) clearTimeout(game.hintTimeout);
  if (game.guessTimeout) clearTimeout(game.guessTimeout);

  if (reasonMsg !== undefined) {
    game.currentTurn = game.currentTurn === "BLUE" ? "RED" : "BLUE";
  }

  game.round = (game.round || 0) + 1;

  game.hintState = {
    phase: "AWAIT_HINT",
    team: game.currentTurn,
    hintWord: null,
    guessCount: null,
    usedGuesses: 0,
  };

  const teamName = game.currentTurn === "BLUE" ? "الأزرق" : "الأحمر";

  if (reasonMsg) {
    await game.channel.send(
      `${reasonMsg}\n\n` +
        `🌀 **الجولة رقم ${game.round}**\n` +
        `الآن يبدأ دور فريق **${teamName}**.\n` +
        `على القائد إرسال التلميح خلال **${config.hintTimeSec}** ثانية.`
    );
  } else {
    await game.channel.send(
      `🔔 تم اختيار الفريق الذي سيبدأ اللعبة بشكل عشوائي.\n` +
        `🌀 **الجولة رقم ${game.round}**\n` +
        `الآن دور فريق **${teamName}**.\n` +
        `على القائد إرسال التلميح خلال **${config.hintTimeSec}** ثانية.`
    );
  }

  await refreshBoard(game);

  game.hintTimeout = setTimeout(() => {
    handleHintTimeout(game);
  }, config.hintTimeSec * 1000);
}

async function handleHintTimeout(game) {
  if (!game.hintState || game.hintState.phase !== "AWAIT_HINT") return;
  const teamName = game.hintState.team === "BLUE" ? "الأزرق" : "الأحمر";
  const msg =
    `⏰ انتهى وقت قائد فريق **${teamName}** لإرسال التلميح.\n` +
    "يتم نقل الدور مباشرة إلى الفريق الآخر.";
  await startNewTurn(game, msg);
}

async function finalizeHint(game) {
  if (!game.hintState) return;
  if (
    !game.hintState.hintWord ||
    !game.hintState.guessCount ||
    game.hintState.phase !== "AWAIT_HINT"
  )
    return;

  if (game.hintTimeout) clearTimeout(game.hintTimeout);

  game.hintState.phase = "GUESSING";
  game.hintState.usedGuesses = 0;

  const teamName = game.hintState.team === "BLUE" ? "الأزرق" : "الأحمر";

  await game.channel.send(
    `🧠 تلميح فريق **${teamName}**: **${game.hintState.hintWord}**\n` +
      `مسموح للفريق اختيار **${game.hintState.guessCount}** كلمة خلال **${config.guessTimeSec}** ثانية.`
  );

  game.guessTimeout = setTimeout(() => {
    handleGuessTimeout(game);
  }, config.guessTimeSec * 1000);
}

async function handleGuessTimeout(game) {
  if (!game.hintState || game.hintState.phase !== "GUESSING") return;
  const teamName = game.hintState.team === "BLUE" ? "الأزرق" : "الأحمر";
  const msg =
    `⏰ انتهى وقت إجابة فريق **${teamName}** لهذه الجولة.\n` +
    "ينتقل الدور الآن إلى الفريق الآخر.";
  await startNewTurn(game, msg);
}

// ---------- Word Click ----------

async function handleWordClick(interaction) {
  const game = getGame(interaction.channel.id);
  if (!game || game.stage !== "IN_PROGRESS") {
    return interaction.reply({
      content: "لا توجد لعبة نشطة الآن في هذه القناة.",
      ephemeral: true,
    });
  }

  const userId = interaction.user.id;
  let team = null;
  if (game.blueTeam.has(userId)) team = "BLUE";
  else if (game.redTeam.has(userId)) team = "RED";

  if (!team) {
    return interaction.reply({
      content: "أنت لست ضمن أي فريق في هذه اللعبة.",
      ephemeral: true,
    });
  }

  if (!game.hintState || game.hintState.phase !== "GUESSING") {
    return interaction.reply({
      content: "لا يمكنك اختيار الكلمات الآن، انتظر حتى يعطي القائد التلميح.",
      ephemeral: true,
    });
  }

  if (team !== game.currentTurn) {
    return interaction.reply({
      content: "ليس دور فريقك حالياً.",
      ephemeral: true,
    });
  }

  const wordId = interaction.customId.replace("word_", "");
  const wordObj = game.boardWords.find((w) => w.id === wordId);
  if (!wordObj || wordObj.chosenBy) {
    return interaction.reply({
      content: "هذه الكلمة تم اختيارها سابقًا.",
      ephemeral: true,
    });
  }

  wordObj.chosenBy = team;
  await refreshBoard(game);

  let msg = "";
  const teamName = team === "BLUE" ? "الأزرق" : "الأحمر";

  if (wordObj.type === "DEADLY") {
    const otherTeam = team === "BLUE" ? "RED" : "BLUE";
    const otherName = otherTeam === "BLUE" ? "الأزرق" : "الأحمر";
    msg =
      `💀 <@${userId}> اختار الكلمة المميتة (**${wordObj.label}**).\n` +
      `فريق **${teamName}** خسر اللعبة مباشرة!\n` +
      `الفريق الفائز: **${otherName}** 🎉`;

    await interaction.reply({ content: "لقد اخترت الكلمة المميتة!", ephemeral: true });
    return endGame(game, otherTeam, msg);
  }

  if (wordObj.type === team) {
    if (team === "BLUE") game.blueScore++;
    else game.redScore++;

    msg = `✅ <@${userId}> اختار كلمة صحيحة لفريق **${teamName}**: (**${wordObj.label}**).`;
  } else if (wordObj.type === "NEUTRAL") {
    msg =
      `🟡 <@${userId}> اختار كلمة محايدة (**${wordObj.label}**).\n` +
      "ينتهي دور فريقه في هذه الجولة.";
    await interaction.reply({ content: "تم تسجيل اختيارك.", ephemeral: true });
    return startNewTurn(game, msg);
  } else {
    msg =
      `❌ <@${userId}> اختار كلمة تخص الفريق الآخر (**${wordObj.label}**).\n` +
      "ينتهي دور فريقه في هذه الجولة.";
    await interaction.reply({ content: "تم تسجيل اختيارك.", ephemeral: true });
    return startNewTurn(game, msg);
  }

  if (game.blueScore >= game.config.targetScore || game.redScore >= game.config.targetScore) {
    const winner = game.blueScore >= game.config.targetScore ? "BLUE" : "RED";
    const winnerName = winner === "BLUE" ? "الأزرق" : "الأحمر";
    msg += `\n\n🏆 فريق **${winnerName}** اكتشف جميع كلماته وفاز بالمباراة!`;
    await interaction.reply({ content: "تم تسجيل اختيارك.", ephemeral: true });
    return endGame(game, winner, msg);
  }

  if (game.hintState && game.hintState.team === team) {
    game.hintState.usedGuesses++;
    if (game.hintState.usedGuesses >= game.hintState.guessCount) {
      msg += `\n🔚 انتهت جميع المحاولات المتاحة لفريق **${teamName}** في هذه الجولة.`;
      await interaction.reply({ content: "تم تسجيل اختيارك.", ephemeral: true });
      return startNewTurn(game, msg);
    }
  }

  await interaction.reply({ content: "تم تسجيل اختيارك.", ephemeral: true });
  await game.channel.send(msg);
}

// ---------- End Game ----------

async function endGame(game, winnerTeam, extraMsg) {
  game.end();
  await restoreChannelPermissions(game);
  deleteGame(game.channel.id);

  if (!winnerTeam) {
    if (extraMsg) await game.channel.send(extraMsg);
    return;
  }

  const winnerName = winnerTeam === "BLUE" ? "الأزرق" : "الأحمر";
  let msg = extraMsg || "";
  msg += `\n\n🎉 مبروك لفريق **${winnerName}**!`;

  const winners = winnerTeam === "BLUE" ? game.blueTeam : game.redTeam;
  const leaderId = winnerTeam === "BLUE" ? game.blueLeader : game.redLeader;

  if (leaderId) addScore(leaderId, 2);
  for (const id of winners) {
    if (id === leaderId) continue;
    addScore(id, 1);
  }

  await game.channel.send(msg);
}

async function showBoard(message) {
  const game = getGame(message.channel.id);
  if (!game || game.stage !== "IN_PROGRESS")
    return message.reply("لا توجد لعبة نشطة حاليًا لعرض اللوحة.");
  if (!game.boardMessage) return message.reply("لم يتم إنشاء اللوحة بعد.");
  return message.reply("هذه هي آخر لوحة تم إرسالها 👇");
}

module.exports = {
  getGame,
  startLobby,
  showBoard,
  handleLobbyButton,
  handleWordClick,
  handleViewTeamWords,
  openHintModal,
  handleHintModalSubmit,
};
