const fs = require("fs");
const path = require("path");
const {
  EmbedBuilder,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
} = require("discord.js");

const WORDS_FILE = path.join(__dirname, "../../words.txt");
let WORD_POOL = [];

try {
  const raw = fs.readFileSync(WORDS_FILE, "utf8");
  WORD_POOL = raw
    .split(/\r?\n/)
    .map((w) => w.trim())
    .filter((w) => w.length > 0);
} catch (e) {
  console.error("تعذر قراءة ملف الكلمات words.txt ، سيتم استخدام قائمة افتراضية.");
  WORD_POOL = [
    "بحر",
    "قمر",
    "شمس",
    "سيارة",
    "جبل",
    "نهر",
    "كتاب",
    "باب",
    "قلم",
    "حديقة",
    "مطار",
    "سفينة",
    "ساعة",
    "كمبيوتر",
    "مكتب",
    "مدرسة",
    "مستشفى",
    "طائرة",
    "صحراء",
    "شجرة"
  ];
}

function generateBoard() {
  const totalBlue = 7;
  const totalRed = 7;
  const totalDeadly = 1;
  const totalNeutral = 5;
  const total = totalBlue + totalRed + totalDeadly + totalNeutral;

  const shuffled = [...WORD_POOL].sort(() => Math.random() - 0.5);
  const selected = shuffled.slice(0, total);

  const result = [];
  let idx = 0;

  for (let i = 0; i < totalBlue; i++) {
    result.push({
      id: `w${idx}`,
      label: selected[idx],
      type: "BLUE",
      chosenBy: null,
    });
    idx++;
  }

  for (let i = 0; i < totalRed; i++) {
    result.push({
      id: `w${idx}`,
      label: selected[idx],
      type: "RED",
      chosenBy: null,
    });
    idx++;
  }

  for (let i = 0; i < totalNeutral; i++) {
    result.push({
      id: `w${idx}`,
      label: selected[idx],
      type: "NEUTRAL",
      chosenBy: null,
    });
    idx++;
  }

  result.push({
    id: `w${idx}`,
    label: selected[idx],
    type: "DEADLY",
    chosenBy: null,
  });
  idx++;

  return result.sort(() => Math.random() - 0.5);
}

function buildBoardComponents(game) {
  const rows = [];
  let row = new ActionRowBuilder();

  for (let i = 0; i < game.boardWords.length; i++) {
    const w = game.boardWords[i];

    let style = ButtonStyle.Secondary;
    if (w.chosenBy) {
      if (w.type === "BLUE") style = ButtonStyle.Primary;
      else if (w.type === "RED") style = ButtonStyle.Danger;
      else if (w.type === "NEUTRAL") style = ButtonStyle.Success;
      else if (w.type === "DEADLY") style = ButtonStyle.Danger;
    }

    const btn = new ButtonBuilder()
      .setCustomId(`word_${w.id}`)
      .setLabel(w.label)
      .setStyle(style)
      .setDisabled(!!w.chosenBy);

    row.addComponents(btn);

    if (row.components.length === 5 || i === game.boardWords.length - 1) {
      rows.push(row);
      row = new ActionRowBuilder();
    }
  }

  const controlRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("view_blue_words")
      .setLabel("🔵 كلمات الأزرق (للقائد)")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId("view_red_words")
      .setLabel("🔴 كلمات الأحمر (للقائد)")
      .setStyle(ButtonStyle.Danger)
  );

  rows.push(controlRow);

  return rows;
}

function buildBoardEmbed(game) {
  const turnText =
    game.currentTurn === "BLUE"
      ? "🔵 الآن دور فريق الأزرق"
      : game.currentTurn === "RED"
      ? "🔴 الآن دور فريق الأحمر"
      : "لم يتم بدء الجولة بعد";

  const roundText = game.round
    ? `🌀 **الجولة رقم ${game.round}**\n`
    : "";

  return new EmbedBuilder()
    .setTitle("🗺️ لوحة لعبة كودنيمز")
    .setDescription(
      `${roundText}${turnText}\n\n` +
        `يفوز الفريق الذي يَكتشف أولاً جميع كلماته الصحيحة (**${game.config.targetScore}** كلمة).\n` +
        "الكلمة المميتة 💀 تجعل الفريق الذي يختارها يخسر فورًا.\n" +
        "الكلمات المحايدة تنهي دور الفريق فقط بدون نقاط."
    )
    .addFields(
      {
        name: "🔵 فريق الأزرق",
        value:
          `القائد: ${
            game.blueLeader ? `<@${game.blueLeader}>` : "لم يتم تعيين قائد بعد"
          }\n` +
          `اللاعبون: ${
            game.blueTeam.size
              ? [...game.blueTeam].map((id) => `<@${id}>`).join("، ")
              : "لا يوجد لاعبون حتى الآن"
          }\n` +
          `الكلمات المكتشفة: ${game.blueScore}/${game.config.targetScore}`,
        inline: true,
      },
      {
        name: "🔴 فريق الأحمر",
        value:
          `القائد: ${
            game.redLeader ? `<@${game.redLeader}>` : "لم يتم تعيين قائد بعد"
          }\n` +
          `اللاعبون: ${
            game.redTeam.size
              ? [...game.redTeam].map((id) => `<@${id}>`).join("، ")
              : "لا يوجد لاعبون حتى الآن"
          }\n` +
          `الكلمات المكتشفة: ${game.redScore}/${game.config.targetScore}`,
        inline: true,
      }
    )
    .setColor(0x2ecc71);
}

module.exports = {
  generateBoard,
  buildBoardComponents,
  buildBoardEmbed,
};
