class GameState {
  constructor(channel, config) {
    this.channel = channel;
    this.config = config;

    this.stage = "LOBBY";

    this.blueLeader = null;
    this.redLeader = null;

    this.blueTeam = new Set();
    this.redTeam = new Set();

    this.boardWords = [];
    this.deadlyWordId = null;
    this.neutralIds = new Set();

    this.currentTurn = null;
    this.blueScore = 0;
    this.redScore = 0;

    this.round = 0;

    this.lobbyMessage = null;
    this.lobbyTimeout = null;
    this.lobbyInterval = null;

    this.boardMessage = null;

    this.hintState = null;
    this.hintTimeout = null;
    this.guessTimeout = null;
  }

  clearAllTimeouts() {
    if (this.lobbyTimeout) clearTimeout(this.lobbyTimeout);
    if (this.lobbyInterval) clearInterval(this.lobbyInterval);
    if (this.hintTimeout) clearTimeout(this.hintTimeout);
    if (this.guessTimeout) clearTimeout(this.guessTimeout);
  }

  end() {
    this.stage = "ENDED";
    this.clearAllTimeouts();
  }
}

module.exports = GameState;
