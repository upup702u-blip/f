const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "../../data");
const FILE_PATH = path.join(DATA_DIR, "leaderboard.json");

let cache = null;

function ensureFile() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(FILE_PATH)) {
    fs.writeFileSync(FILE_PATH, JSON.stringify({}, null, 2), "utf8");
  }
}

function load() {
  ensureFile();
  if (cache) return cache;
  try {
    const raw = fs.readFileSync(FILE_PATH, "utf8");
    cache = JSON.parse(raw || "{}");
  } catch (e) {
    cache = {};
  }
  return cache;
}

function save() {
  ensureFile();
  fs.writeFileSync(FILE_PATH, JSON.stringify(cache || {}, null, 2), "utf8");
}

function addScore(userId, points) {
  const lb = load();
  if (!lb[userId]) lb[userId] = 0;
  lb[userId] += points;
  if (lb[userId] < 0) lb[userId] = 0;
  cache = lb;
  save();
}

function clearLeaderboard() {
  cache = {};
  save();
}

function getLeaderboardText() {
  const lb = load();
  const entries = Object.entries(lb);
  if (!entries.length) {
    return "لا توجد أي نقاط حتى الآن.";
  }
  entries.sort((a, b) => b[1] - a[1]);
  let lines = [];
  for (let i = 0; i < entries.length && i < 20; i++) {
    const [id, score] = entries[i];
    lines.push(`**${i + 1}.** <@${id}> — **${score}** نقطة`);
  }
  return lines.join("\n");
}

module.exports = {
  addScore,
  clearLeaderboard,
  getLeaderboardText,
};
