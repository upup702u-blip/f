const rawConfig = require("../config.json");

const config = {
  token: rawConfig.token,
  prefix: rawConfig.prefix || "-",
  owners: rawConfig.owners || [],
  allowedChannels: rawConfig.allowedChannels || [],
  gameRoleId: rawConfig.gameRoleId || null,
  lobbyTimeSec: rawConfig.lobbyTimeSec || 120,
  targetScore: rawConfig.targetScore || 7,
  maxPlayersPerTeam: rawConfig.maxPlayersPerTeam || 6,
  hintTimeSec: rawConfig.hintTimeSec || 80,
  guessTimeSec: rawConfig.guessTimeSec || 100,
};

function isOwner(userId) {
  return config.owners.includes(userId);
}

function isChannelAllowed(channelId) {
  if (!config.allowedChannels || config.allowedChannels.length === 0) return true;
  return config.allowedChannels.includes(channelId);
}

module.exports = {
  config,
  isOwner,
  isChannelAllowed,
};
