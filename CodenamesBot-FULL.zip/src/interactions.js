const {
  handleLobbyButton,
  handleWordClick,
  handleViewTeamWords,
  openHintModal,
  handleHintModalSubmit,
} = require("./game/GameManager");

async function handleInteraction(interaction, client) {
  if (interaction.isButton()) {
    const id = interaction.customId;

    if (
      id === "join_blue_leader" ||
      id === "join_blue_player" ||
      id === "join_red_leader" ||
      id === "join_red_player" ||
      id === "leave_game"
    ) {
      return handleLobbyButton(interaction);
    }

    if (id === "view_blue_words") {
      return handleViewTeamWords(interaction, "BLUE");
    }

    if (id === "view_red_words") {
      return handleViewTeamWords(interaction, "RED");
    }

    if (id.startsWith("open_hint_")) {
      const team = id.endsWith("BLUE") ? "BLUE" : "RED";
      return openHintModal(interaction, team);
    }

    if (id.startsWith("word_")) {
      return handleWordClick(interaction);
    }
  }

  if (interaction.isModalSubmit()) {
    if (
      interaction.customId === "hint_modal_BLUE" ||
      interaction.customId === "hint_modal_RED"
    ) {
      return handleHintModalSubmit(interaction);
    }
  }
}

module.exports = {
  handleInteraction,
};
