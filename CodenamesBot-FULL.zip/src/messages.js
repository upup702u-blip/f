const { config, isChannelAllowed, isOwner } = require("./config");
const { handleOwnerCommand } = require("./commands/ownerCommands");
const { handleGameCommand } = require("./commands/gameCommands");

async function handleMessage(message, client) {
  if (!message.guild) return;
  if (message.author.bot) return;

  const prefix = config.prefix || "-";
  if (!message.content.startsWith(prefix)) return;

  if (!isChannelAllowed(message.channel.id) && !isOwner(message.author.id)) {
    return;
  }

  const args = message.content.slice(prefix.length).trim().split(/\s+/);
  const command = args.shift().toLowerCase();

  await handleOwnerCommand(message, command, args, client);
  await handleGameCommand(message, command, args);
}

module.exports = {
  handleMessage,
};
