const { Client, GatewayIntentBits, Partials } = require("discord.js");
const { config } = require("./config");
const { handleMessage } = require("./messages");
const { handleInteraction } = require("./interactions");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel]
});

client.once("ready", () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
});

client.on("messageCreate", (message) => {
  handleMessage(message, client);
});

client.on("interactionCreate", (interaction) => {
  handleInteraction(interaction, client);
});

client.login(config.token);
