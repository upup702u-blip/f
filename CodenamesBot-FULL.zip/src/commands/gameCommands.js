const { EmbedBuilder } = require("discord.js");
const {
  startLobby,
  showBoard,
} = require("../game/GameManager");
const { getLeaderboardText } = require("../game/leaderboard");
const { config, isOwner } = require("../config");

async function handleGameCommand(message, command, args) {
  if (command === "كودنيمز" || command === "codenames") {
    const gameRoleId = config.gameRoleId;

    if (gameRoleId && !isOwner(message.author.id)) {
      const member = message.member;
      if (!member || !member.roles.cache.has(gameRoleId)) {
        return message.reply(
          "❌ لا يمكنك تشغيل اللعبة. هذا الأمر متاح فقط للأونر أو لأصحاب الرتبة التي حددها الأونر."
        );
      }
    }

    return startLobby(message);
  }

  if (command === "لوحة" || command === "board") {
    return showBoard(message);
  }

  if (command === "صدارة" || command === "top") {
    const lb = getLeaderboardText();
    const embed = new EmbedBuilder()
      .setTitle("🏆 قائمة الصدارة")
      .setDescription(lb)
      .setColor(0xf1c40f);
    return message.channel.send({ embeds: [embed] });
  }
}

module.exports = {
  handleGameCommand,
};
