const { config, isOwner } = require("../config");
const { clearLeaderboard, addScore } = require("../game/leaderboard");
const { EmbedBuilder } = require("discord.js");

async function handleOwnerCommand(message, command, args, client) {
  if (!isOwner(message.author.id)) return;

  const prefix = config.prefix || "-";

  if (command === "help" || command === "مساعدة") {
    const embed = new EmbedBuilder()
      .setTitle("📚 أوامر بوت كودنيمز")
      .setDescription(
        "جميع الأوامر الخاصة بهذا البوت.\n" +
          "استخدم البادئة: `" + prefix + "` قبل كل أمر.\n" +
          "مثال: `" + prefix + "كودنيمز`"
      )
      .addFields(
        {
          name: "🎮 أوامر اللعبة",
          value:
            "`" + prefix + "كودنيمز` : فتح لوبي للعبة.\n" +
            "`" + prefix + "codenames` : نفس الأمر.\n" +
            "`" + prefix + "لوحة` / `board` : عرض اللوحة.\n" +
            "`" + prefix + "صدارة` / `top` : عرض نقاط الصدارة.",
        },
        {
          name: "🛠 أوامر الأونر",
          value:
            "`" + prefix + "botsetchat #channel` : تحديد قناة اللعبة.\n" +
            "`" + prefix + "botclearchat` : إلغاء تقييد القناة.\n" +
            "`" + prefix + "botsetrole @role` : تحديد رتبة تشغيل اللعبة.\n" +
            "`" + prefix + "ownerlist` : عرض قائمة الأونرز.\n" +
            "`" + prefix + "botaddowner @user` : إضافة أونر.\n" +
            "`" + prefix + "botremoveowner @user` : حذف أونر.\n" +
            "`" + prefix + "botname الاسم` : تغيير اسم البوت.\n" +
            "`" + prefix + "botavatar` + صورة : تغيير صورة البوت.\n" +
            "`" + prefix + "botstatus النص` : تغيير حالة البوت.\n" +
            "`" + prefix + "cleartop` : مسح الصدارة.\n" +
            "`" + prefix + "addpoints @user العدد` : إضافة نقاط.\n" +
            "`" + prefix + "restart` : إعادة تشغيل البوت.",
        }
      )
      .setColor(0x2f3136);

    return message.reply({ embeds: [embed] });
  }

  if (command === "botsetchat" || command === "botsetchannel") {
    if (!message.guild) return message.reply("❌ هذا الأمر يعمل داخل السيرفر فقط.");

    let channel =
      message.mentions.channels.first() ||
      message.guild.channels.cache.get(args[0] || "") ||
      message.channel;

    if (!channel) {
      return message.reply(
        "❌ لم أستطع العثور على القناة.\n" +
          "استخدم:\n" +
          "`" + prefix + "botsetchat #channel`"
      );
    }

    config.allowedChannels = [channel.id];

    const embed = new EmbedBuilder()
      .setTitle("📌 قناة اللعبة")
      .setDescription(`سيعمل البوت الآن فقط في: ${channel}`)
      .setColor(0x57f287);

    return message.reply({ embeds: [embed] });
  }

  if (command === "botclearchat") {
    config.allowedChannels = [];

    const embed = new EmbedBuilder()
      .setTitle("📌 إلغاء تقييد القناة")
      .setDescription("سيعمل البوت الآن في جميع القنوات (إلا إذا تم تعيين قناة جديدة).")
      .setColor(0xfee75c);

    return message.reply({ embeds: [embed] });
  }

  if (command === "botsetrole") {
    if (!message.guild) return message.reply("❌ هذا الأمر يعمل داخل السيرفر فقط.");

    const role =
      message.mentions.roles.first() ||
      message.guild.roles.cache.get(args[0] || "");

    if (!role) {
      return message.reply(
        "❌ منشن الرتبة أو اكتب آي دي الرتبة.\n" +
          "مثال:\n`" + prefix + "botsetrole @GameRole`"
      );
    }

    config.gameRoleId = role.id;

    const embed = new EmbedBuilder()
      .setTitle("🎯 رتبة اللعبة")
      .setDescription(
        `الرتبة الوحيدة (مع الأونر) المسموح لها بتشغيل اللعبة هي:\n<@&${role.id}>`
      )
      .setColor(0x57f287);

    return message.reply({ embeds: [embed] });
  }

  if (command === "ownerlist") {
    const owners = config.owners || [];
    if (!owners.length) {
      return message.reply("ℹ️ لا توجد أي آي ديهات مسجلة كأونرز حالياً.");
    }

    const lines = owners.map((id, i) => `**${i + 1}.** <@${id}> \`(${id})\``);
    const embed = new EmbedBuilder()
      .setTitle("👑 قائمة الأونرز")
      .setDescription(lines.join("\n"))
      .setColor(0xf1c40f);

    return message.reply({ embeds: [embed] });
  }

  if (command === "botaddowner") {
    const user = message.mentions.users.first();
    if (!user) {
      return message.reply(
        "❌ منشن الشخص.\nمثال:\n`" + prefix + "botaddowner @user`"
      );
    }
    if (!config.owners.includes(user.id)) config.owners.push(user.id);
    return message.reply(`✅ تمت إضافة <@${user.id}> إلى الأونرز.`);
  }

  if (command === "botremoveowner") {
    const user = message.mentions.users.first();
    if (!user) {
      return message.reply(
        "❌ منشن الشخص.\nمثال:\n`" + prefix + "botremoveowner @user`"
      );
    }
    if (!config.owners.includes(user.id)) {
      return message.reply("❌ هذا الشخص ليس من الأونرز.");
    }

    config.owners = config.owners.filter((id) => id !== user.id);
    return message.reply(`✅ تمت إزالة <@${user.id}> من الأونرز.`);
  }

  if (command === "botname") {
    const name = args.join(" ");
    if (!name)
      return message.reply("❌ اكتب الاسم الجديد.\nمثال:\n`" + prefix + "botname Codenames`");
    try {
      await client.user.setUsername(name);
      return message.reply(`✅ تم تغيير اسم البوت إلى **${name}**.`);
    } catch (e) {
      console.error(e);
      return message.reply("❌ تعذر تغيير اسم البوت (ربما غيّرت الاسم قبل قليل).");
    }
  }

  if (command === "botavatar") {
    const att = message.attachments.first();
    if (!att) return message.reply("❌ أرسل صورة مع الأمر.");
    try {
      await client.user.setAvatar(att.url);
      return message.reply("✅ تم تغيير صورة البوت.");
    } catch (e) {
      console.error(e);
      return message.reply("❌ تعذر تغيير صورة البوت.");
    }
  }

  if (command === "botstatus") {
    const text = args.join(" ");
    if (!text)
      return message.reply(
        "❌ اكتب نص الحالة.\nمثال:\n`" + prefix + "botstatus يلعب كودنيمز`"
      );
    client.user.setPresence({
      activities: [{ name: text }],
      status: "online",
    });
    return message.reply("✅ تم تغيير حالة البوت.");
  }

  if (command === "cleartop") {
    clearLeaderboard();
    return message.reply("✅ تم مسح قائمة الصدارة.");
  }

  if (command === "addpoints") {
    const user = message.mentions.users.first();
    const pts = parseInt(args[1], 10);
    if (!user || isNaN(pts)) {
      return message.reply(
        "❌ الصيغة الصحيحة:\n`" +
          prefix +
          "addpoints @user عدد_النقاط`"
      );
    }
    addScore(user.id, pts);
    return message.reply(`✅ تم إضافة **${pts}** نقطة إلى <@${user.id}>.`);
  }

  if (command === "restart") {
    await message.reply("🔁 جاري إعادة تشغيل البوت...");
    process.exit(0);
  }
}

module.exports = {
  handleOwnerCommand,
};
